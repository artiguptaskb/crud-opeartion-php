<?php
$id=$_GET['id'];
$connect=mysqli_connect("localhost","root","","asthaanimation");
$sql= "DELETE FROM `student_result` WHERE `id`= $id";

mysqli_query($connect,$sql);
header("location:view.php");

?>
