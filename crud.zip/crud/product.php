<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>


<div class="row g-0">
<?php
$connect=mysqli_connect("localhost","root","","asthaanimation");
$sql="SELECT * FROM `student_result`";
$result=mysqli_query($connect,$sql);
while($value=mysqli_fetch_assoc($result)){

?>
    <div class="col-md-4">
        <div class="card m-2">

        <div class="card-image">
            <img src="image/<?php echo $value['photo']; ?>"  width="100%">
            <div class="card-body">
                <div class="card-tittle">
                    <h4><?php  echo $value['name'];?></h4>

                </div>
                <div>
                    <button class="btn btn-primary">Enroll now</button>
                </div>
            </div>

        </div>

        </div>


    </div>


<?php
}
?>
</div>
    
</body>
</html>