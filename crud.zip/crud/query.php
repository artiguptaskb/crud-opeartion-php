<?php
session_start();
if($_POST['username']!="" && $_POST['password']!="" && $_POST['class']!="" && $_POST['number']!="" && $_POST['email']!="" ){
    $name=$_POST['username'];
    $password=implode(",",$_POST['password']);
    $class=$_POST['class'];
    $number=$_POST[''];
    $email=$_POST['email'];
    $gender=$_POST['gender'];
    $unum=substr($email,0,-13);
    $photoname=$unum.$_FILES['photo']['name'];
    $phototmp=$_FILES['photo']['tmp_name'];
    $photosize=$_FILES['photo']['size']/(1024*1024);
    $fileurl="image/".$photoname;
    $vexten=pathinfo($photoname,PATHINFO_EXTENSION);
    $confess=['jpg','jpeg','webp','png'];
    if(in_array($vexten,$confess)){

        if($photosize < 1){
    move_uploaded_file($phototmp,$fileurl);
    $connect=mysqli_connect("localhost","root","","asthaanimation") or die ("error");
    $sql="INSERT INTO `student_result`(`id`,`name`,`password`,`class`,`email`,`phone`,`photo`,`gender`) VALUES ('$id','$name','$password','$class','$email','$number','$photoname','$gender')";
    mysqli_query($connect,$sql);
    $_SESSION['student']="form submit successfully";
    header("location:index.php");
        }

    else{
        $_SESSION['student']="file  size less then 1mb";
        header("location:index.php");
        }
    }

    else{
        $_SESSION['student']="jpg jpeg webp png";
        header("location:index.php");
    }
}
    
else{
    $_SESSION['student']="error";
    header("location:index.php");
}




    
    ?>
    

