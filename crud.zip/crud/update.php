<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</head>
<body>

<div class="row g-0">

    <div class="col-md-4">

    </div>
    <div class="col-md-4">
    <?php
        $id=$_GET['id'];
            $servername="localhost";
            $username="root";
            $password="";
            $databasename="asthaanimation";
            $connect=mysqli_connect($servername,$username,$password,$databasename);
            $sql="SELECT * FROM `student_result` WHERE `id`=$id";
            $result=mysqli_query($connect,$sql);
            while($value=mysqli_fetch_assoc($result)){
        ?>

    <form class="bg-danger text-light  p-4 mt-5" method="POST" enctype="multipart/form-data">
        <input type="text" name="id" value="<?php echo $value ['id'];?>">
        <input class="form-control mt-2" type="text" name="username" value="<?php  echo $value ['name'];?>" placeholder="enterusername">
        <input class="form-control mt-2" type="text"  name="password" value ="<?php echo $value ['password'];?>" placeholder="enterpassword">
        <input class="form-control mt-2" type="text"  name="class" value ="<?php echo $value ['class'];?>"placeholder="enter class ">
        <input class="form-control mt-2" type="text"  name="phone" value ="<?php echo $value ['phone'];?>"placeholder="enter number ">
        <input class="form-control mt-2" type="text"  name="email" value ="<?php echo $value ['email'];?>"placeholder="enter emailid">
        <input class="form-control mt-3" type="submit"  value="Apply now"  name="update">
    </form>
<?php






    }

?>
</div>
<div class="col-md-4">

</div>
    </div>

    <?php
    if(isset($_POST['update'])){
        $id=$_POST['id'];
        $username=$_POST['username'];
        $password=$_POST['password'];
        $class=$_POST['class'];
        $phone=$_POST['phone'];
        $email=$_POST['email'];
        $connect=mysqli_connect("localhost","root","","asthaanimation");
        $usql="UPDATE `student_result` SET `name`='$username',`password`='$password',`class`='$class',`phone`='$phone',`email`=' $email' WHERE `id`=$id";
        mysqli_query($connect,$usql);
        header("localhost:view.php");
    
    
    }
?>    

    
</body>
</html>