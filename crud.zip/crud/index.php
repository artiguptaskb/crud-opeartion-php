<!-- 
database mai insert data session thrue -->


<?php session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</head>
<body>


<?php 


if(isset($_SESSION['student'])){
    ?>

<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong>form submit successsfully</strong><?php $_SESSION['student'];?> 
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
}


session_destroy();
?>
    <div class="row g-0">

    <div class="col-md-4">

    </div>
    <div class="col-md-4">
        <form action="query.php" class="bg-danger text-light  p-4 mt-5" method="POST" enctype="multipart/form-data">
        <input class="form-control mt-2" type="text" name="username" placeholder="enterusername">
        <input class="form-control mt-2" type="password"  name="password"  placeholder="enterpassword">
        <input class="form-control mt-2" type="text"  name="class" placeholder="enter class ">
        <input class="form-control mt-2" type="text"  name="number" placeholder="enter number">
        <input class="form-control mt-2" type="text"  name="email"placeholder="enter emailid">
       
        Select Gender
        <input type="checkbox" name="gender" value="male">male
        <input type="checkbox" name="gender" value="female">female

        <input type="radio" name="password[]" value="digital marketing" > digital marketing
        <input type="radio" name="password[]" value="2d animation" >2D animation
        <input type="radio" name="passowrd[]" value="3d animation"> 3D


        <input type="text" name="password[]" placeholder="Enter Course Name 1" class="form-control">
        <input type="text" name="password[]" placeholder="Enter Course Name 2" class="form-control">
        <input type="text" name="password[]" placeholder="Enter Course Name 3" class="form-control">

             <br>Student photo

        <input type="file" name="photo">
        <input class="form-control mt-3" type="submit"  value="Apply now"  name="submit">
    </form>

</div>
<div class="col-md-4">

</div>
    </div>


  

</body>
</html>