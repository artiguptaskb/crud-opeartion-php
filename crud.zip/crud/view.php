<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>

<table class="table">
    <tr>
        <td>id</td>
        <td>name</td>
        <td>password</td>
        <td>class</td>
        <td>number</td>
        <td>email</td>
        <td>photo</td>
        <td>Delete</td>
        <td>action</td>
    </tr>
    <?php

   $connect=mysqli_connect("localhost","root","","asthaanimation");
   $sql= " SELECT * FROM `student_result`";
   $result= mysqli_query($connect,$sql);
   while($rohit=mysqli_fetch_assoc($result)){
    ?>

    <tr>
        <!-- <td><?php echo $rohit ['id'];?></td> -->
        <td><?php echo $rohit ['name'];?></td>
        <td><?php echo $rohit ['password'];?></td>
        <td><?php echo $rohit ['class'];?></td>
        <td><?php echo $rohit ['phone'];?></td>
        <td><?php echo $rohit ['email'];?></td>
        <td><?php echo $rohit ['photo'];?></td>
        <td><a href="delete.php?id=<?php echo $rohit['id'];?>"><button class="btn btn-danger">delete</button></a></td>       
        <td><a href="update.php?id=<?php echo $rohit['id'];?>"><button class="btn btn-success">update</button></a></td>       
        


    </tr>
    <?php
   }
    
    
    ?>
</table>

    
</body>
</html>